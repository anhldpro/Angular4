"use strict";
var Customer = (function () {
    function Customer() {
        this.CustomerName = "";
        this.CustomerCode = "";
        this.CustomerAmount = 0;
    }
    return Customer;
}());
exports.Customer = Customer;
//# sourceMappingURL=Customer.js.map